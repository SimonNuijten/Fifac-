﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        const string SAVE_LOCATION = "saved-game.json";

        string fullSchedule;
        FetchSchedule fetchedSchedule;
        
        public int Amount = 25;

        public string saveJson0;

        Save save = new Save();
        Save save0 = new Save();

        public Form1()
        {
            InitializeComponent();
            // retrieve matches
            System.Net.WebClient client = new System.Net.WebClient();
            string read = client.DownloadString("http://simonnuijten.nl/bracket2.php?token=570724329");
            fetchedSchedule = JsonConvert.DeserializeObject<FetchSchedule>(read);
        }

        

       


        private void Form1_Load(object sender, EventArgs e)
        {
            const string SAVE_LOCATION = "saved-game.json";

            // set money saved from last time
            if(File.Exists(SAVE_LOCATION))
            {
                string saveJson0 = File.ReadAllText(SAVE_LOCATION);

                Save desave0 = JsonConvert.DeserializeObject<Save>(saveJson0);

                label4.Text = desave0.cash.ToString();
            }
            

                      

            timer1.Enabled = true;

            string team = "team";
            string response;

            // retrieve teams
            var url = string.Format("http://simonnuijten.nl/teams.php?token=570724329", team);
            using (var webClient = new WebClient())
            {
                response = webClient.DownloadString(url);

                Teams teams = JsonConvert.DeserializeObject<Teams>(response);


                // display retrieved teams
                for (int i = 0; i < teams.names.Count; i++)
                {
                    favCombobox.Items.Add(teams.names[i].ToString());
                   

                }

            }
        }

        

        private void timer1_Tick(object sender, EventArgs e)
        {
            usernameLabel.Text = "Welkom " + Program.username;
            label4.Text = "Saldo";
            moneyLabel.Text = Program.cash.ToString();

        }










        public void SetBet()
        {



                

                Program.cash -= 1 * Amount;

                save.name = Program.username;
                save.cash = Program.cash;




                save.team1 = leftteamCombobox.Text;
                save.team2 = rightteamCombobox.Text;
                save.favteam = favCombobox.Text;

                save.score1 = leftteamGoalsTextBox.Text;
                save.score2 = rightteamGoalsTextBox.Text;

                string saveJson = JsonConvert.SerializeObject(save);
                // Write the saved bet to a text file
                File.WriteAllText(SAVE_LOCATION, saveJson);

          

        }

    

       
        public void betButton_Click(object sender, EventArgs e)
        {
            // check if you've got enough money
            if (int.Parse(moneyLabel.Text) <= 0)
            {
                MessageBox.Show("te weinig geld");
            }
            else
            {

                SetBet();
            }


        }

       

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {


            // automatically divide the match to their teams
            string a = comboBox2.Text.Split('-')[0];

            leftteamCombobox.Text = a.Trim().ToString();


            string b = comboBox2.Text.Split('-')[1];

            rightteamCombobox.Text = b.Trim().ToString();


        }

       
        private void label4_Click(object sender, EventArgs e)
        {
            // cheatcode
            if (comboBox2.Text == "v@kogam3s")
            {

                Program.cash += 50;
            }
        }

        private void favCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            fullSchedule = "";

            var favo = favCombobox.Text;

            // only display matches that contain the selected team
            foreach (var item in fetchedSchedule.matches)

            {

                if (item.Contains(favo))
                {

                    
                    comboBox2.Items.Add(item);
                }

            }

        }

       
        

        private void CheckScore_Click(object sender, EventArgs e)
        {

            int Amount = 25;

            const string SAVE_LOCATION = "saved-game.json";

            string saveJson = File.ReadAllText(SAVE_LOCATION);
            // unpack saved values
            Save desave = JsonConvert.DeserializeObject<Save>(saveJson);

            List<FetchScores> fetchedScores;
            // retrieve scores
            System.Net.WebClient client = new System.Net.WebClient();
            string read3 = client.DownloadString("http://simonnuijten.nl/matchesApi.php?token=570724329");
            fetchedScores = JsonConvert.DeserializeObject<List<FetchScores>>(read3);

            string both = leftteamCombobox.Text + " - " + rightteamCombobox.Text;



            foreach (FetchScores scor in fetchedScores)


            {
                if (desave.team1 == desave.favteam && desave.team1 + desave.team2 == scor.team1 + scor.team2 || desave.team2 == desave.favteam && desave.team1 + desave.team2 == scor.team1 + scor.team2)
                {


                    if (scor.played == 0)
                    {
                        MessageBox.Show("je team heeft nog niet gespeeld");
                    }
                    else
                    {

                        if (desave.score1 + desave.score2 == scor.score1.ToString() + scor.score2.ToString() && scor.played == 1)
                        {
                            MessageBox.Show("JA, je hebt de uitslag goed geraden!");
                            MessageBox.Show("Daadwerkelijke uitslag:" + scor.score1.ToString() + " - " + scor.score2.ToString());
                            int money = Program.cash += Amount * 3;
                            label4.Text = money.ToString();
                            save.cash = Program.cash;

                            string saveJson1 = JsonConvert.SerializeObject(save);
                            File.WriteAllText(SAVE_LOCATION, saveJson1);

                        }

                        if (desave.score1 + desave.score2 != scor.score1.ToString() + scor.score2.ToString() && scor.played == 1)
                        {
                            MessageBox.Show("Helaas, je hebt de uitslag fout..");
                            MessageBox.Show("Daadwerkelijke uitslag:" + scor.score1.ToString() + " - " + scor.score2.ToString());
                         
                        }
                    }
                }
            }
              
        }

        private void CheckWon_Click(object sender, EventArgs e)
        {
            int Amount = 25;

            const string SAVE_LOCATION = "saved-game.json";

            string saveJson = File.ReadAllText(SAVE_LOCATION);
            //unpack saved values
            Save desave = JsonConvert.DeserializeObject<Save>(saveJson);

            List<FetchScores> fetchedScores;

            System.Net.WebClient client = new System.Net.WebClient();
            string read3 = client.DownloadString("http://simonnuijten.nl/matchesApi.php?token=570724329");
            fetchedScores = JsonConvert.DeserializeObject<List<FetchScores>>(read3);

            



            foreach (FetchScores scor in fetchedScores)


            {
                

                if (desave.team1 == desave.favteam && desave.team1 + desave.team2 == scor.team1 + scor.team2)
                {
                    if (scor.played == 0)
                    {
                        MessageBox.Show("je team heeft nog niet gespeeld");
                    }
                    else
                    {
                        if (int.Parse(desave.score1) > int.Parse(desave.score2) && scor.score1 > scor.score2 && scor.played == 1 || int.Parse(desave.score1) < int.Parse(desave.score2) && scor.score1 > scor.score2 && scor.played == 1)
                        {
                            MessageBox.Show("je team heeft gewonnen");
                            MessageBox.Show("Daadwerkelijke uitslag:" + scor.score1.ToString() + " - " + scor.score2.ToString());
                            int money = Program.cash += Amount * 2;
                            label4.Text = money.ToString();
                            save.cash = Program.cash;

                            string saveJson1 = JsonConvert.SerializeObject(save);
                            File.WriteAllText(SAVE_LOCATION, saveJson1);

                        }
                        if (int.Parse(desave.score1) > int.Parse(desave.score2) && scor.score1 == scor.score2 && scor.played == 1 || int.Parse(desave.score1) < int.Parse(desave.score2) && scor.score1 == scor.score2 && scor.played == 1)
                        {
                            MessageBox.Show("gelijk spel!");
                            MessageBox.Show("Daadwerkelijke uitslag:" + scor.score1.ToString() + " - " + scor.score2.ToString());
                        }
                        if (int.Parse(desave.score1) < int.Parse(desave.score2) && scor.score1 < scor.score2 && scor.played == 1 || int.Parse(desave.score1) > int.Parse(desave.score2) && scor.score1 < scor.score2 && scor.played == 1)
                        {
                            MessageBox.Show("je team heeft verloren");
                            MessageBox.Show("Daadwerkelijke uitslag:" + scor.score1.ToString() + " - " + scor.score2.ToString());
                            int money = Program.cash -= Amount;
                            label4.Text = money.ToString();
                            save.cash = Program.cash;

                            string saveJson1 = JsonConvert.SerializeObject(save);
                            File.WriteAllText(SAVE_LOCATION, saveJson1);

                        }

                    }

                }

                if (desave.team2 == desave.favteam && desave.team1 + desave.team2 == scor.team1 + scor.team2)
                {
                   

                    if (scor.played == 0)
                    {
                        MessageBox.Show("je team heeft nog niet gespeeld");
                    }
                    else
                    {
                        if (int.Parse(desave.score2) > int.Parse(desave.score1) && scor.score1 == scor.score2 && scor.played == 1 || int.Parse(desave.score2) < int.Parse(desave.score1) && scor.score1 == scor.score2 && scor.played == 1)
                        {
                            MessageBox.Show("gelijk spel!");
                            MessageBox.Show("Daadwerkelijke uitslag:" + scor.score2.ToString() + " - " + scor.score1.ToString());
                        }

                        if (int.Parse(desave.score2) > int.Parse(desave.score1) && scor.score1 < scor.score2 && scor.played == 1 || int.Parse(desave.score2) < int.Parse(desave.score1) && scor.score1 < scor.score2 && scor.played == 1)
                        {
                            MessageBox.Show("je team heeft gewonnen");
                            MessageBox.Show("Daadwerkelijke uitslag:" + scor.score1.ToString() + " - " + scor.score2.ToString());
                            int money = Program.cash += Amount * 2;
                            label4.Text = money.ToString();
                            save.cash = Program.cash;

                            string saveJson1 = JsonConvert.SerializeObject(save);
                            File.WriteAllText(SAVE_LOCATION, saveJson1);

                        }

                       
                        if (int.Parse(desave.score2) < int.Parse(desave.score1) && scor.score1 > scor.score2 && scor.played == 1 || int.Parse(desave.score2) > int.Parse(desave.score1) && scor.score1 > scor.score2 && scor.played == 1)
                        {
                            MessageBox.Show("je team heeft verloren");
                            MessageBox.Show("Daadwerkelijke uitslag:" + scor.score1.ToString() + " - " + scor.score2.ToString());
                            int money = Program.cash -= Amount;
                            label4.Text = money.ToString();
                            save.cash = Program.cash;

                            string saveJson1 = JsonConvert.SerializeObject(save);
                            File.WriteAllText(SAVE_LOCATION, saveJson1);

                        }
                    }
                }
                    
            }

        }
    }
}
