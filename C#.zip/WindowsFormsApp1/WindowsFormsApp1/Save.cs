﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class Save
    {
        public string name { get; set; }

        public int cash { get; set; }

        public string team1 { get; set; }

        public string team2 { get; set; }

        public string score1 { get; set; }

        public string score2 { get; set; }

        public string favteam { get; set; }
    }
}
